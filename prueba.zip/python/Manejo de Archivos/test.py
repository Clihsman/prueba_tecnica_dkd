import json
import unittest
from convertir_csv_json import convertir_csv_a_json

def test_conversion():
    convertir_csv_a_json("usuarios.csv", "usuarios.json")
        # ...