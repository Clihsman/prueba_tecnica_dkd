import csv
import json

def convertir_csv_a_json(archivo_csv, archivo_json):
    try:
        with open(archivo_csv, mode='r', encoding='utf-8') as csv_file:
            lector_csv = csv.DictReader(csv_file)
            datos = [fila for fila in lector_csv]
        
        with open(archivo_json, mode='w', encoding='utf-8') as json_file:
            json.dump(datos, json_file, indent=4)
    except Exception as e:
        print(f"Error al procesar los archivos: {e}")

if __name__ == "__main__":
    convertir_csv_a_json("Manejo de Archivos/usuarios.csv", "Manejo de Archivos/usuarios.json")