from abc import ABC, abstractmethod

# Constantes
SALARIO_MINIMO = 84000  # Valor del salario mínimo
AUXILIO_TRANSPORTE = 12600  # Valor del auxilio de transporte

# Clase base Usuario
class Usuario(ABC):
    def __init__(self, nombre: str, palabra_clave: str, edad: int):
        self._nombre = nombre
        self._palabra_clave = palabra_clave
        self._edad = edad

    @abstractmethod
    def calcular_salario(self) -> int:
        pass

    def obtener_nombre(self):
        return self._nombre

# Usuario Administrativo
class UsuarioAdministrativo(Usuario):
    def calcular_salario(self) -> int:
        return SALARIO_MINIMO + AUXILIO_TRANSPORTE

# Usuario por Prestación de Servicios
class UsuarioPrestacionServicios(Usuario):
    def __init__(self, nombre: str, palabra_clave: str, edad: int, tarifa_hora: int, horas_trabajadas: int):
        super().__init__(nombre, palabra_clave, edad)
        self._tarifa_hora = tarifa_hora
        self._horas_trabajadas = horas_trabajadas

    def calcular_salario(self) -> int:
        return self._tarifa_hora * self._horas_trabajadas

# Usuario de Término Directivo
class UsuarioTerminoDirectivo(Usuario):
    NIVELES = {"ING": 1.45, "Gerente": 1.45, "Presidente": 1.45}
    
    def __init__(self, nombre: str, palabra_clave: str, edad: int, nivel: str):
        super().__init__(nombre, palabra_clave, edad)
        self._nivel = nivel

    def calcular_salario(self) -> int:
        return int(SALARIO_MINIMO * self.NIVELES.get(self._nivel, 1))

# Pruebas Unitarias
import unittest

class TestUsuarios(unittest.TestCase):
    def test_usuario_administrativo(self):
        usuario = UsuarioAdministrativo("Ana", "clave123", 30)
        self.assertEqual(usuario.calcular_salario(), SALARIO_MINIMO + AUXILIO_TRANSPORTE)

    def test_usuario_prestacion_servicios(self):
        usuario = UsuarioPrestacionServicios("Luis", "clave456", 25, 5000, 20)
        self.assertEqual(usuario.calcular_salario(), 5000 * 20)

    def test_usuario_termino_directivo(self):
        usuario = UsuarioTerminoDirectivo("Carlos", "clave789", 40, "Gerente")
        self.assertEqual(usuario.calcular_salario(), int(SALARIO_MINIMO * 1.45))
        
    
if __name__ == "__main__":
    usuario1 = UsuarioAdministrativo("Ana", "clave123", 30)
    usuario2 = UsuarioPrestacionServicios("Luis", "clave456", 25, 5000, 20)
    usuario3 = UsuarioTerminoDirectivo("Carlos", "clave789", 40, "Gerente")

    print(f"Salario Usuario Administrativo: {usuario1.calcular_salario()}")
    print(f"Salario Usuario Prestación de Servicios: {usuario2.calcular_salario()}")
    print(f"Salario Usuario Término Directivo: {usuario3.calcular_salario()}")
    unittest.main()

