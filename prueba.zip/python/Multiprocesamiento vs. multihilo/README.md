# Comparación entre Threading y Multiprocessing en Python

## Descripción
Este proyecto demuestra el uso de concurrencia en Python utilizando los módulos `threading` y `multiprocessing`. Se comparan sus desempeños en dos tipos de tareas:

1. **Descarga de datos simulada** (I/O-bound): Se simula una descarga con `time.sleep()`, representando una tarea que espera una operación de entrada/salida.
2. **Cálculo de números primos** (CPU-bound): Se buscan todos los números primos hasta un límite dado, representando una tarea que requiere alto uso de CPU.

## Uso
Ejecuta el script `concurrencia.py` para comparar ambos enfoques:

```bash
python concurrencia.py
```

## Resultados esperados
- `Threading` es más eficiente para tareas de entrada/salida (I/O-bound) porque permite que un hilo siga ejecutándose mientras otro espera.
- `Multiprocessing` es más eficiente para tareas intensivas en CPU (CPU-bound) porque cada proceso se ejecuta en su propio núcleo de CPU.

## ¿Cuándo usar threading vs multiprocessing?

| Caso de uso          | Recomendación |
|----------------------|--------------|
| Tareas I/O-bound (lectura/escritura de archivos, descarga de datos, acceso a bases de datos) | **Usar `threading`** |
| Tareas CPU-bound (cálculos matemáticos intensivos, procesamiento de imágenes, simulaciones) | **Usar `multiprocessing`** |

## Evaluación
Este proyecto evalúa:
✅ Uso correcto de `threading` y `multiprocessing`  
✅ Estructura modular y clara  
✅ Comparación del rendimiento entre ambos enfoques  
✅ Explicación en este README  

## Conclusión
Ambos métodos tienen ventajas dependiendo del tipo de tarea. Para optimizar el rendimiento, elige `threading` para tareas que dependen de I/O y `multiprocessing` para aquellas que requieren procesamiento intensivo en CPU.

