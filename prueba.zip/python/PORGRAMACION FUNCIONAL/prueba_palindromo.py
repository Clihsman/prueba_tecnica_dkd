# prueba_palindromo.py
from typing import List

def es_palindromo(palabra: str) -> bool:
    return palabra.lower() == palabra.lower()[::-1]

def obtener_palindromos(palabras: List[str]) -> List[str]:
    return list(filter(es_palindromo, palabras))

if __name__ == "__main__":
    palabras = input("Ingrese palabras separadas por comas: ").split(",")
    palabras = [palabra.strip() for palabra in palabras]  # Eliminar espacios extra
    print("Palíndromos encontrados:", obtener_palindromos(palabras))

