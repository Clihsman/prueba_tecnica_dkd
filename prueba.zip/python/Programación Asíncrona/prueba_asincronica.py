import asyncio
import aiohttp
import unittest

# Lista de URLs simuladas
urls = [
    "https://api.ejemplo.com/datos/1",
    "https://api.ejemplo.com/datos/2",
    "https://api.ejemplo.com/datos/3"
]

async def fetch_data(session, url):
    """Función asíncrona para realizar una solicitud HTTP con aiohttp."""
    async with session.get(url) as response:
        return await response.json()

async def fetch_all_data(urls):
    """Ejecuta múltiples solicitudes de manera concurrente."""
    async with aiohttp.ClientSession() as session:
        tasks = [fetch_data(session, url) for url in urls]
        return await asyncio.gather(*tasks)

if __name__ == "__main__":
    results = asyncio.run(fetch_all_data(urls))
    for result in results:
        print(result)

# Pruebas con unittest
class TestAsyncFunctions(unittest.IsolatedAsyncioTestCase):
    async def test_fetch_data(self):
        """Prueba la función fetch_data con una URL de prueba."""
        async with aiohttp.ClientSession() as session:
            test_url = "https://jsonplaceholder.typicode.com/todos/1"
            data = await fetch_data(session, test_url)
            self.assertIn("userId", data)

    async def test_fetch_all_data(self):
        """Prueba la ejecución de múltiples solicitudes."""
        test_urls = ["https://jsonplaceholder.typicode.com/todos/1"]
        results = await fetch_all_data(test_urls)
        self.assertEqual(len(results), len(test_urls))

if __name__ == "__main__":
    unittest.main()
