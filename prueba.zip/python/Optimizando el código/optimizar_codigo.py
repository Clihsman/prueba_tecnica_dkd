# optimizar_codigo.py

def procesar_lista_optimizada(numeros):
    """
    Procesa una lista de números eliminando duplicados y ordenándolos de menor a mayor.
    Más eficiente que la versión original.
    """
    return sorted(set(numeros))

if __name__ == "__main__":
    numeros = [5, 3, 8, 3, 1, 5, 2, 8, 1]
    resultado = procesar_lista_optimizada(numeros)
    print(resultado)


#Problemas en el código original
#if num not in lista_unicos tiene una complejidad de O(n) en el peor caso porque recorre toda la lista para verificar la existencia del número.
#Como el bucle for ya recorre la lista una vez (O(n)), esto genera una complejidad total de O(n²) en el peor caso.
#El método sort() tiene una complejidad de O(n log n), lo que aumenta aún más el tiempo de ejecución.

#Código optimizado
#En lugar de recorrer la lista y verificar manualmente si un número ya está en lista_unicos, se usa set(numeros), que automáticamente elimina duplicados en O(n).
#Los conjuntos en Python están implementados como tablas hash, por lo que la inserción y búsqueda tienen una complejidad O(1) en promedio.
#sorted(set(numeros)) convierte el conjunto en una lista ordenada usando el algoritmo Timsort, con una complejidad de O(n log n).