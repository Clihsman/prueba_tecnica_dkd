# test.py
import unittest
from optimizar_codigo import procesar_lista_optimizada

class TestProcesarLista(unittest.TestCase):
    def test_procesar_lista(self):
        self.assertEqual(procesar_lista_optimizada([5, 3, 8, 3, 1, 5, 2, 8, 1]), [1, 2, 3, 5, 8])
        self.assertEqual(procesar_lista_optimizada([]), [])
        self.assertEqual(procesar_lista_optimizada([4, 4, 4, 4]), [4])
        self.assertEqual(procesar_lista_optimizada([10, 5, 20, 10, 5, 20]), [5, 10, 20])
    
    def test_eficiencia(self):
        import time
        numeros = list(range(1000000, 0, -1)) * 2  # Lista con un millón de elementos duplicados
        start_time = time.time()
        procesar_lista_optimizada(numeros)
        execution_time = time.time() - start_time
        self.assertLess(execution_time, 1)  # Aseguramos que se ejecute en menos de 1 segundo

if __name__ == "__main__":
    unittest.main()
