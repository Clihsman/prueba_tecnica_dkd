from collections import deque

class Pedido:
    def __init__(self, numero_orden, nombre_cliente, productos):
        self.numero_orden = numero_orden
        self.nombre_cliente = nombre_cliente
        self.productos = productos
        self.estado = "Pendiente"
    
    def actualizar_estado(self, nuevo_estado):
        if nuevo_estado in ["Pendiente", "En preparación", "Listo", "Entregado"]:
            self.estado = nuevo_estado
        else:
            raise ValueError("Estado no válido")

class GestionPedidos:
    def __init__(self):
        self.pedidos = deque()
        self.pedidos_dict = {}
    
    def agregar_pedido(self, numero_orden, nombre_cliente, productos):
        if numero_orden in self.pedidos_dict:
            raise ValueError("Número de orden ya existe")
        pedido = Pedido(numero_orden, nombre_cliente, productos)
        self.pedidos.append(pedido)
        self.pedidos_dict[numero_orden] = pedido
    
    def actualizar_estado_pedido(self, numero_orden, nuevo_estado):
        if numero_orden not in self.pedidos_dict:
            raise ValueError("Pedido no encontrado")
        self.pedidos_dict[numero_orden].actualizar_estado(nuevo_estado)
    
    def listar_pedidos(self):
        return list(self.pedidos)
    
    def listar_pedidos_pendientes(self):
        return [pedido for pedido in self.pedidos if pedido.estado == "Pendiente"]
    
    def buscar_pedido(self, numero_orden):
        return self.pedidos_dict.get(numero_orden, None)

if __name__ == "__main__":
    gestion = GestionPedidos()
    while True:
        print("\n1. Agregar nuevo pedido")
        print("2. Actualizar estado de un pedido")
        print("3. Listar todos los pedidos")
        print("4. Listar pedidos pendientes")
        print("5. Buscar pedido por número de orden")
        print("6. Salir")
        
        opcion = input("Seleccione una opción: ")
        
        if opcion == "1":
            numero_orden = int(input("Número de orden: "))
            nombre_cliente = input("Nombre del cliente: ")
            productos = input("Ingrese los productos separados por coma: ").split(",")
            gestion.agregar_pedido(numero_orden, nombre_cliente, productos)
            print("Pedido agregado exitosamente.")
        
        elif opcion == "2":
            numero_orden = int(input("Número de orden del pedido a actualizar: "))
            nuevo_estado = input("Nuevo estado (Pendiente, En preparación, Listo, Entregado): ")
            try:
                gestion.actualizar_estado_pedido(numero_orden, nuevo_estado)
                print("Estado actualizado correctamente.")
            except ValueError as e:
                print(e)
        
        elif opcion == "3":
            pedidos = gestion.listar_pedidos()
            for pedido in pedidos:
                print(f"Orden {pedido.numero_orden}: {pedido.nombre_cliente} - {pedido.estado} - Productos: {', '.join(pedido.productos)}")
        
        elif opcion == "4":
            pedidos_pendientes = gestion.listar_pedidos_pendientes()
            for pedido in pedidos_pendientes:
                print(f"Orden {pedido.numero_orden}: {pedido.nombre_cliente} - {pedido.estado} - Productos: {', '.join(pedido.productos)}")
        
        elif opcion == "5":
            numero_orden = int(input("Número de orden a buscar: "))
            pedido = gestion.buscar_pedido(numero_orden)
            if pedido:
                print(f"Orden {pedido.numero_orden}: {pedido.nombre_cliente} - {pedido.estado} - Productos: {', '.join(pedido.productos)}")
            else:
                print("Pedido no encontrado.")
        
        elif opcion == "6":
            print("Saliendo del sistema...")
            break
        
        else:
            print("Opción no válida, intente de nuevo.")
