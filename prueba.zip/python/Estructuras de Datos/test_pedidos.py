import unittest
from gestionar_pedidos import GestionPedidos, Pedido

class TestGestionPedidos(unittest.TestCase):
    def setUp(self):
        self.gestion = GestionPedidos()
        self.gestion.agregar_pedido(1, "Mario", ["Pizza", "Refresco"])
        self.gestion.agregar_pedido(2, "Luigi", ["Pasta", "Agua"])
    
    def test_agregar_pedido(self):
        self.gestion.agregar_pedido(3, "Peach", ["Ensalada", "Jugo"])
        pedido = self.gestion.buscar_pedido(3)
        self.assertIsNotNone(pedido)
        self.assertEqual(pedido.nombre_cliente, "Peach")
    
    def test_actualizar_estado_pedido(self):
        self.gestion.actualizar_estado_pedido(1, "En preparación")
        pedido = self.gestion.buscar_pedido(1)
        self.assertIsNotNone(pedido)
        self.assertEqual(pedido.estado, "En preparación")
    
    def test_listar_pedidos(self):
        pedidos = self.gestion.listar_pedidos()
        self.assertEqual(len(pedidos), 2)
        self.assertEqual(pedidos[0].numero_orden, 1)
        self.assertEqual(pedidos[1].numero_orden, 2)
    
    def test_listar_pedidos_pendientes(self):
        pedidos_pendientes = self.gestion.listar_pedidos_pendientes()
        self.assertEqual(len(pedidos_pendientes), 2)
        self.gestion.actualizar_estado_pedido(1, "Listo")
        pedidos_pendientes = self.gestion.listar_pedidos_pendientes()
        self.assertEqual(len(pedidos_pendientes), 1)
        self.assertEqual(pedidos_pendientes[0].numero_orden, 2)
    
    def test_buscar_pedido(self):
        pedido = self.gestion.buscar_pedido(2)
        self.assertIsNotNone(pedido)
        self.assertEqual(pedido.numero_orden, 2)
        self.assertEqual(pedido.nombre_cliente, "Luigi")
    
    def test_pedido_no_existente(self):
        pedido = self.gestion.buscar_pedido(99)
        self.assertIsNone(pedido)

if __name__ == "__main__":
    unittest.main()
